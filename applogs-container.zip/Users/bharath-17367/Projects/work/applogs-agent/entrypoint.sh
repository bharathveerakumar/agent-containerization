#!/bin/bash
set -e

INSTALL_DIR=/opt/site24x7
MONAGENT_HOME=$INSTALL_DIR/monagent
MAIN_AGENT_CONF_DIR=$MONAGENT_HOME/conf
MAIN_AGENT_MONAGENT_CFG=$MAIN_AGENT_CONF_DIR/monagent.cfg
LOGS_DIR=$MONAGENT_HOME/logs
APPLOG_AGENT_LIB=$MONAGENT_HOME/lib
APPLOG_STARTER=$APPLOG_AGENT_LIB/applog/applog_starter.py
VENV_PYTHON=$INSTALL_DIR/venv/bin/python
APPLOG_ZIP_NAME=applog_source_agent.zip
DOWNLOAD_URL="https://staticdownloads.site24x7.com/server/$APPLOG_ZIP_NAME"

# Parse agent_key from the [AGENT_INFO] section of monagent.cfg
get_agent_key() {
    if [[ ! -f "$MAIN_AGENT_MONAGENT_CFG" ]]; then
        return 1
    fi
    awk -F '=' '
        /^\[AGENT_INFO\]/ { in_section=1; next }
        /^\[/             { in_section=0 }
        in_section && /^[[:space:]]*agent_key[[:space:]]*=/ {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
            print $2
            exit
        }
    ' "$MAIN_AGENT_MONAGENT_CFG"
}

# Wait until the main agent registers and receives its agent key
wait_for_agent_key() {
    printf "Waiting for main agent to register and set agent_key...\n"
    while true; do
        AGENT_KEY=$(get_agent_key || true)
        if [[ -n "$AGENT_KEY" && "$AGENT_KEY" != "0" ]]; then
            printf "agent_key detected: %s\n" "$AGENT_KEY"
            return 0
        fi
        printf "agent_key not yet available. Retrying in 10 seconds...\n"
        sleep 10
    done
}

# Download and extract the applog source agent
download_and_extract() {
    printf "Downloading applog agent from %s\n" "$DOWNLOAD_URL"
    wget -q -P "$INSTALL_DIR" "$DOWNLOAD_URL"

    printf "Extracting %s into %s\n" "$APPLOG_ZIP_NAME" "$MONAGENT_HOME"
    unzip -o "$INSTALL_DIR/$APPLOG_ZIP_NAME" -d "$MONAGENT_HOME"
    rm -f "$INSTALL_DIR/$APPLOG_ZIP_NAME"

    mkdir -p "$LOGS_DIR"
}

# Main entrypoint logic
wait_for_agent_key
download_and_extract

printf "Starting applog agent: %s (using %s)\n" "$APPLOG_STARTER" "$VENV_PYTHON"
"$VENV_PYTHON" "$APPLOG_STARTER" &
APPLOG_PID=$!

/opt/watcher.sh &
WATCHER_PID=$!

# Wait for either the applog agent or the watcher to exit.
# If one exits, kill the other and exit the container so K8s can restart it.
wait -n "$APPLOG_PID" "$WATCHER_PID"
EXIT_CODE=$?

printf "A child process exited (code %d). Shutting down...\n" "$EXIT_CODE"
kill "$APPLOG_PID" "$WATCHER_PID" 2>/dev/null || true
wait 2>/dev/null || true

exit "$EXIT_CODE"
