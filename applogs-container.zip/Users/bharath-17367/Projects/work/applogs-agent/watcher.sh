#!/bin/bash

MONAGENT_DIR=/opt/site24x7/monagent

# If the monagent directory doesn't exist, exit immediately to trigger container restart
if [[ ! -d "$MONAGENT_DIR" ]]; then
    printf "watcher: %s does not exist. Exiting to trigger restart.\n" "$MONAGENT_DIR"
    exit 1
fi

printf "watcher: Watching %s for deletion...\n" "$MONAGENT_DIR"

# Block until the directory is deleted or moved
inotifywait -e delete_self -e move_self "$MONAGENT_DIR"

printf "watcher: %s was deleted/moved. Exiting to trigger container restart.\n" "$MONAGENT_DIR"
exit 0